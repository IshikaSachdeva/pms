import { Injectable } from '@angular/core';
import { user } from '../model/user';
@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  users: user[] = [
    new user(1, 'ishu', 'ishika', 'Welcome'),
    new user(2, 'isha', 'hika', 'Hi'),
    new user(3, 'ishika', 'isha', '2406'),
    new user(4, 'ishi', 'ishima', '242318')
  ];
}
