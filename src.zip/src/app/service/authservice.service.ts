
import { inject, Injectable } from '@angular/core';
import { UserserviceService } from './userservice.service';
 
@Injectable({
  providedIn: 'root'
})
export class AuthserviceService  {
 
  constructor() { }
 
  isLogged: boolean = false;
userservice: UserserviceService = inject(UserserviceService);
 
  login(un: string, pw: string) {
    let user = this.userservice.users.find((u) => u.name === un && u.pass === pw);
 
    if (user === undefined) {
      this.isLogged = false;
    }
    else {
      this.isLogged = true;
    }
    return user;
  }
  logout() {
    this.isLogged = false;
  }
  isAuthenticated(): boolean {
    return this.isLogged;
  }
 
}
 
 