import { inject, Inject, Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, CanActivate, GuardResult, MaybeAsync, Router, RouterStateSnapshot } from "@angular/router";
import { Observable } from "rxjs";
import { AuthserviceService } from "./authservice.service";

 
@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {
  r: Router = inject(Router);
  as:AuthserviceService = inject(AuthserviceService);
 
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean>
  {
    if(this.as.isAuthenticated())
    {
      return true;
    }
    else
    {
      this.r.navigate(['/login']);
      return false;
    }
  }
}