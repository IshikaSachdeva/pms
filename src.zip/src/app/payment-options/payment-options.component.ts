import { Component, OnInit, OnDestroy } from '@angular/core'; 
import { Subscription, interval } from 'rxjs'; 
import { takeWhile } from 'rxjs/operators';

@Component({
  selector: 'app-payment-options',
  templateUrl: './payment-options.component.html',
  styleUrls: ['./payment-options.component.css']
})
export class PaymentOptionsComponent implements OnInit, OnDestroy{
  showPaymentOptions: boolean = false;
  paymentMessage: string = '';
  showPaymentDialog: boolean = false;
  paymentType: string = ''; 
  upiId: string = ''; 
  showModal: boolean = false; 
  showAmountModal: boolean = false;
  amount: number = 0; 
  showQR: { [key: string]: boolean } = 
  { googlepay: false, phonepay: false, upi: false, cash: false, }; 
  generateRandomUPI() 
  { const upiIds = ['random1@upi', 'random2@upi', 'random3@upi', 'random4@upi']; 
    this.upiId = upiIds[Math.floor(Math.random() * upiIds.length)]; 
  } 
  setPaymentType(type: string) 
  { this.paymentType = type; 
    this.showQR[type] = !this.showQR[type];
     // Toggle the QR display 
  if (type === 'upi' && this.showQR[type]) 
  { this.generateRandomUPI(); } 
  if (type === 'phonepay') 
  { this.showPaymentDialog = true; } 
  else { this.showPaymentDialog = false; } 
} 
selectPaymentOption(option: string) {
   switch(option) { 
    case 'monthly': this.amount = 100; 
    this.paymentMessage = `Pay ₹${this.amount}`; 
    break; 
    case 'daily': this.amount = 150; 
    this.paymentMessage = `Pay ₹${this.amount}`; 
    break; 
    case 'guest': this.amount = 200; 
    this.paymentMessage = `Pay ₹${this.amount}`; 
    break; 
    default: this.amount = 0; 
    this.paymentMessage = ''; break; 
  } alert(this.paymentMessage); 
  this.showPaymentOptions = false; // Hide options after selection 
  }
  processPayment() 
  { this.showPaymentDialog = false; 
  alert('The amount is credited. You can have your card. It will be received soon!');
}
  minutes: number = 10; 
  seconds: number = 0; 
  private subscription!: Subscription; 
  private isTimerRunning: boolean = false; 
  //showModal: boolean = false; // To control the display of the modal 
  ngOnInit(): void { // Initialize logic if needed 
    } ngOnDestroy(): void 
    { // Clean up subscription to avoid memory leaks 
      this.subscription?.unsubscribe(); 
    } showCustomAlert(): void {
      this.showModal = true; 
    } confirmPayment(): void 
    { this.showModal = false; 
      alert('Proceeding with the payment...'); 
      // Add payment confirmation logic here 
      } cancelPayment(): void 
      { this.showModal = false; alert('Payment cancelled.'); 
        this.stopTimer(); 
      } startPayment(): void 
      { if (this.isTimerRunning) 
        { return; } 
        this.isTimerRunning = true; 
        this.subscription = interval(1000).pipe( takeWhile(() => this.minutes > 0 || this.seconds > 0) ).subscribe(() => 
          { if (this.seconds === 0) { if (this.minutes > 0) { this.minutes--; this.seconds = 59; } } 
        else { this.seconds--; } if (this.minutes === 0 && this.seconds === 0) 
          { alert('Time is up! Payment session expired.'); this.isTimerRunning = false; 

          } }); } 
          stopTimer(): void { this.isTimerRunning = false; this.subscription?.unsubscribe(); // Unsubscribe from the timer interval 
            } 
            showPaymentOptionsDialog() { this.showPaymentOptions = true; }
          closeAmountModal(): void { this.showAmountModal = false; }}
