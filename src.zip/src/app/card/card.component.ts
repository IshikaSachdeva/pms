import { Component } from '@angular/core';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-card',
  templateUrl: './card.component.html',
  styleUrls: ['./card.component.css']
})
export class CardComponent {
  cards = [
    { user: 'John Doe', number: '1234 5678 9012 3456', expiry: '12/2025', vehicle: 'Car' },
    { user: 'Jane Doe', number: '9876 5432 1098 7654', expiry: '01/2026', vehicle: 'Bike' },
    { user: 'Alice Smith', number: '2234 5678 9012 3456', expiry: '03/2025', vehicle: 'Car' },
    { user: 'Bob Johnson', number: '3234 5678 9012 3456', expiry: '05/2026', vehicle: 'Bike' },
    { user: 'Charlie Brown', number: '4234 5678 9012 3456', expiry: '07/2025', vehicle: 'Car' },
    { user: 'David Wilson', number: '5234 5678 9012 3456', expiry: '09/2025', vehicle: 'Bike' },
    { user: 'Eve Davis', number: '6234 5678 9012 3456', expiry: '11/2025', vehicle: 'Car' },
    { user: 'Frank Clark', number: '7234 5678 9012 3456', expiry: '02/2026', vehicle: 'Bike' },
    { user: 'Grace Miller', number: '8234 5678 9012 3456', expiry: '04/2025', vehicle: 'Car' },
    { user: 'Henry Harris', number: '9234 5678 9012 3456', expiry: '06/2026', vehicle: 'Bike' },
    { user: 'Ivy Walker', number: '1234 5678 1012 3456', expiry: '08/2025', vehicle: 'Car' },
    { user: 'Jack Young', number: '2345 6789 0123 4567', expiry: '10/2025', vehicle: 'Bike' },
    { user: 'Kelly King', number: '3456 7890 1234 5678', expiry: '12/2026', vehicle: 'Car' },
    { user: 'Liam Wright', number: '4567 8901 2345 6789', expiry: '01/2025', vehicle: 'Bike' },
    { user: 'Mia Scott', number: '5678 9012 3456 7890', expiry: '03/2026', vehicle: 'Car' },
    { user: 'Noah Lewis', number: '6789 0123 4567 8901', expiry: '05/2025', vehicle: 'Bike' },
    { user: 'Olivia Robinson', number: '7890 1234 5678 9012', expiry: '07/2025', vehicle: 'Car' },
    { user: 'Paul Carter', number: '8901 2345 6789 0123', expiry: '09/2026', vehicle: 'Bike' },
    { user: 'Quincy Evans', number: '9012 3456 7890 1234', expiry: '11/2025', vehicle: 'Car' },
    { user: 'Rachel Baker', number: '0123 4567 8901 2345', expiry: '01/2026', vehicle: 'Bike' }
  ];

  downloadCard(card: any) {
    const element = document.getElementById(`card-${card.user}`);
    if (element) {
      html2canvas(element).then(canvas => {
        const imgData = canvas.toDataURL('image/png');
        const pdf = new jsPDF();
        pdf.addImage(imgData, 'PNG', 10, 10, canvas.width / 4, canvas.height / 4);
        pdf.save(`${card.user}-Card.pdf`);
      });
    }
  }
}
