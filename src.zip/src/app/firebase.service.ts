import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { member } from './members/model';  // Import the Member interface

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  private firebaseUrl = 'https://your-firebase-project-id.firebaseio.com';  // Replace with your Firebase URL

  constructor(private http: HttpClient) { }

  // Method to add a member
  addMember(member: member): Observable<member> {
    return this.http.post<member>(`${this.firebaseUrl}/members.json`, member);
  }

  // Method to get all members
  getMembers(): Observable<member[]> {
    return this.http.get<member[]>(`${this.firebaseUrl}/members.json`);
  }
}
