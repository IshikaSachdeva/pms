
 
export class user
{
    id:number;
    name:string;
    role:string;
    pass:string;
 
    constructor(i:number,n:string,r:string,p:string)
    {
        this.id=i;
        this.name=n;
        this.role=r;
        this.pass=p;
    }
}
 