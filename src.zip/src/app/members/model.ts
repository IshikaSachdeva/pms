export interface member {
    name: string;
    vehicle: string;
    type: string;
    paymentStatus: string;
  }
  