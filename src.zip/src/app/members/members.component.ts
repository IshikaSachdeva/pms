import { Component } from '@angular/core';

@Component({
  selector: 'app-members',
  templateUrl: './members.component.html',
  styleUrls: ['./members.component.css']
})
export class MembersComponent {
  members = [
    { name: 'John Doe', type: 'Monthly', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Jane Doe', type: 'Daily', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Alice Smith', type: 'Monthly', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Bob Johnson', type: 'Guest', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Charlie Brown', type: 'Daily', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'David Wilson', type: 'Guest', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Eve Davis', type: 'Monthly', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Frank Clark', type: 'Monthly', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Grace Miller', type: 'Guest', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Henry Harris', type: 'Daily', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Ivy Walker', type: 'Daily', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Jack Young', type: 'Monthly', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Kelly King', type: 'Guest', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Liam Wright', type: 'Daily', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Mia Scott', type: 'Monthly', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Noah Lewis', type: 'Guest', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Olivia Robinson', type: 'Monthly', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Paul Carter', type: 'Guest', vehicle: 'Bike', paymentStatus: 'Paid' },
    { name: 'Quincy Evans', type: 'Daily', vehicle: 'Car', paymentStatus: 'Paid' },
    { name: 'Rachel Baker', type: 'Daily', vehicle: 'Bike', paymentStatus: 'Paid' }
  ];
}
