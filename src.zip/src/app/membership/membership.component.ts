import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-membership',
  templateUrl: './membership.component.html',
  styleUrls: ['./membership.component.css']
})
export class MembershipComponent {
  membershipType: string = '';

  constructor(private router: Router) {}

  setMembershipType(type: string) {
    this.membershipType = type;
  }

  onFormSubmit(formData: any) {
    // Logic to store the formData in the members list
    this.router.navigate(['/payment-options']);
  }
}
