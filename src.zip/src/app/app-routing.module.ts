import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PaymentOptionsComponent } from './payment-options/payment-options.component';
import { MembershipComponent } from './membership/membership.component';
import { MembersComponent } from './members/members.component';
import { CardComponent } from './card/card.component';
import { SigncomponentComponent } from './signcomponent/signcomponent.component';
import { AuthGuardService } from './service/authguard.service';

const routes: Routes = [
  { path: '', redirectTo: '/payment-options', pathMatch: 'full' },
  { path: 'payment-options', component: PaymentOptionsComponent },
  { path: 'membership', component: MembershipComponent },
  { path: 'members', component: MembersComponent },
  { path: 'card', component: CardComponent,canActivate:[AuthGuardService] },
  { path: 'login', component:  SigncomponentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
