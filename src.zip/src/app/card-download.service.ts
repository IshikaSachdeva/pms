import { Injectable } from '@angular/core';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

@Injectable({
  providedIn: 'root'
})
export class CardDownloadService {

  constructor() { }

  downloadCard(cardElement: HTMLElement, fileName: string) {
    html2canvas(cardElement).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF();
      pdf.addImage(imgData, 'PNG', 10, 10, canvas.width / 4, canvas.height / 4);
      pdf.save(fileName);
    });
  }
}
