import { Component, ElementRef, inject, ViewChild } from '@angular/core';
import { AuthserviceService } from '../service/authservice.service';
@Component({
  selector: 'app-signcomponent',
  templateUrl: './signcomponent.component.html',
  styleUrl: './signcomponent.component.css'
})
export class SigncomponentComponent {

  @ViewChild('username') un!: ElementRef;
  @ViewChild('password') pw!: ElementRef;

  aservice: AuthserviceService = inject(AuthserviceService);

  OnLogin() {
    const username = this.un.nativeElement.value;
    const password = this.pw.nativeElement.value;
    const user = this.aservice.login(username, password);
    if (user === undefined) {
      alert('Not allowed');
    } else {
      alert('Welcome ' + user.name + '! You are logged in');
    }
  }
 
}




